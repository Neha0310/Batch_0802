To create a pre-install disk for 32-bit Win2K/WinXP/Win2003/Vista, please copy all files in the floppy32 folder to the root directory of a floppy disk.
To create a pre-install disk for 64-bit WinXP/Win2003/Vista, please copy all files in the floppy64 folder to the root directory of a floppy disk.
