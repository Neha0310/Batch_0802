package StaticKeyword;

import static java.lang.System.*;
public class StaticKeywordExample {
	
	public static void m1() {
		 out.println("Static mi");
	}
	public static void m2() {
		 out.println("Static m2");
	}
	
	public static void m3() {
		System.out.println("Static m3");
	}
	
	public static void m4() {
		System.out.println("Static m4");
	}
	
//	int i=100;
//	
//	// static 
//	static {
//		out.println("Static Block");
//	}
//	//non static
//	{
//		out.println("Non Static Block");
//	}
//	public StaticKeywordExample() {
//		out.println("Const");
//	}
//       
//     public int  sum() {
//    	 int a= 20;
//    	 int b= 40;
//    	 i= a+b;
//    	 return i; 
//     }
//     public static void main(String[] args) {
//    	 StaticKeywordExample obj =new StaticKeywordExample();
//     }
//	public static void main(String[] args) {
//		 System.out.println(i);
//		 
//
//	}

}
