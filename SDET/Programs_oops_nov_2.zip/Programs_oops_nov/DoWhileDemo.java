
public class DoWhileDemo {

	public static void main(String[] args) {
		 int i=1;
		do {
			System.out.println("enter");
			System.out.println(i);//1
			
			 i++;
			 System.out.println("increment-"+i);
			 System.out.println("========");
				
		}while(i<=5);

		System.out.println("Exit");
	}

}
