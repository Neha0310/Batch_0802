package OOPSConcept;

public  class ReferenceVariableDemo {
	
	public static void main(String[] args) {
		 ReferenceVariableDemo obj = new ReferenceVariableDemo() ;
		System.out.println(obj);

	}

}
