package OOPSConcept;

public class MainClass {
	int b;
	public static void main(String[] args) {
		VariablesPracticeDemo obj = new VariablesPracticeDemo();
		System.out.println(obj.a);
		System.out.println(obj.b);
		MainClass obj2 = new MainClass();
		System.out.println(obj2.b);
	}

}
