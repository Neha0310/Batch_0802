package Programs.ArraysPrograms;

import StaticKeyword.StaticKeywordExample;
import static StaticKeyword.StaticKeywordExample.*;
public class MainClass {

	public static void main(String[] args) {
		m1();
		m2();
		m3();
		m4();
		
//		StaticKeywordExample obj1 = new StaticKeywordExample();
//		StaticKeywordExample obj2= new StaticKeywordExample();
//		obj1.i=900;
//		System.out.println(obj1.i);
//		System.out.println(obj2.i);
		 

	}

}
