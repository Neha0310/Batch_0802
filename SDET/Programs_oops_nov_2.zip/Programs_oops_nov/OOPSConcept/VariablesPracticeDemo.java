package OOPSConcept;

public class VariablesPracticeDemo {
	int a=80;
	  int b=900;
	//VariablesPracticeDemo obj;
//	public static void main(String[] args) {
//		System.out.println("Before Changes"); 
//		//System.out.println(a);
//		System.out.println(b);//900
//		//System.out.println(obj);
//		
//		int b=500;//local
//		VariablesPracticeDemo obj1 = new VariablesPracticeDemo();
//		VariablesPracticeDemo obj2 = new VariablesPracticeDemo();
//		obj1.a=877;//80-877
//		System.out.println(obj1.a);//877
//		System.out.println(obj1.b);//900
//		System.out.println(b);//500
//		
//		obj2.b=8900;
//		System.out.println(obj2.a);//80
//		System.out.println(obj2.b);//8900
//
//		System.out.println(b);//500
//		b=3456;
//		System.out.println(b);//3456
//		
//	}

}
